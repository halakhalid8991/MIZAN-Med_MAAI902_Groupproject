SehaCheck - IEEE Access manuscript (Overleaf project)

1. In Overleaf: New Project > Upload Project > select this ZIP.
2. Main document: main.tex. Compiler: pdfLaTeX (Overleaf default).
3. Click Recompile (twice if references show "?").

Files: ieeeaccess.cls, IEEEtran.cls, spotcolor.sty, logos and t1-* font files
are the official IEEE Access template files and must stay in the project root.

source_material/report_notes_not_in_paper.tex keeps the report-only content
(reference renumbering note, "Recommended newer references" table and
Appendix B Individual Contributions) that is not part of an IEEE paper.
